var1 = int(input("Enter value 1 : "))
var2 = int(input("Enter value 2 : "))
temp = var1
var1 = var2
var2 = temp
print(f"swap of two are {var1} , {var2}")
