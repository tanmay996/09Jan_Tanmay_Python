# Write a Python program to count the occurrences of each word in a given sentence
str1="The cat sat on the windowsill, watching the raindrops on the glass, while the clock on the wall marked the passing of time"
print(str1.count("the"),"times \'the' word")