var1 = int(input("Enter value 1 : "))
var2 = int(input("Enter value 2 : "))
var1 = var1+var2
var2 = var1 - var2
var1 = var1 - var2
print(f"swap of two values are {var1} , {var2}")