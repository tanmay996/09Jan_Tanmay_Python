var1 = int(input("Enter value  :"))
if (var1 > 0):
    print("value is positive")
elif(var1 < 0):
    print("value is negative")
elif(var1 == 0):
    print("value is zero")
else:
    print("invalid input")