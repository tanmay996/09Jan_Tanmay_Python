# Write a Python program to count occurrences of a substring in a string.
strn = input("Enter a string for count substring: ")
countstr = strn.split()
print(len(countstr))