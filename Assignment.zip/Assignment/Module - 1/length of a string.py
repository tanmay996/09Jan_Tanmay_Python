## Write a Python program to calculate the length of a string
strn = input("Enter a string for calculate length : ")
print("Length of string is :",len(strn))
