var1 = int(input("Enter value :"))
if (var1 % 2 ==0 ):
    print(f"Value {var1} is even")
else:
    print(f"Value {var1}is odd")