# Write a Python program to test whether a passed letter is a vowel or not.
varLetter = input("Enter letter for check vowel or not : ")
if varLetter == "a" or varLetter == "e" or varLetter == "i" or varLetter =="o" or varLetter == "u" or varLetter == "A" or varLetter == "E" or varLetter == "I" or varLetter =="" or varLetter == "U" :
    print(varLetter,"is Vowel")
else:
    print(varLetter,"is not a Vowel")




