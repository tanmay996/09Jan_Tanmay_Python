# Write a Python program to sum of three given integers. However, if
# two values are equal sum will be zero

var1 =int(input("Enter Value:"))
var2 =int(input("Enter Value:"))
var3 =int(input("Enter Value:")) 
total=var1+var2+var3   

if var1==var2:
    print(var1-var2)
elif var2==var3: 
    print(var2-var3)
elif var3==var1:
    print(var3-var1)

else:
    print("Value is: ",total)


    
 
    
 
         
    

        
      
